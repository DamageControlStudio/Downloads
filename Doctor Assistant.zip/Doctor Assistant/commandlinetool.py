import logging, pickle
from datetime import date, timedelta

"""
这是命令行版的查房助手
新添加功能也应首先放到这里
跟界面交互有关的不在这
"""


global chuanghao, fangjian, ch_fj__dict
chuanghao = ["43", "44", "45", "46", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "1", "2", "3", "4", "5", "6", "加"]
fangjian = ["观", "观", "观", "观", "907", "908", "909", "910", "910", "913", "913", "913", "913", "915", "915", "915", "915", "916", "916", "916", "916", "917", "917", "917", "917", "重症", "重症", "重症", "重症", "重症", "重症", "空"]
ch_fj_dict = {key: value for key, value in zip(chuanghao, fangjian)}

class HuanZhe:
	def __init__(self, xingming="", xingbie="", nianling=0, chuanghao="加", ruyuanriqi=""):
		self.xingming = xingming
		self.xingbie = xingbie
		self.nianling = nianling
		self.chuanghao = chuanghao
		if self.chuanghao in ch_fj_dict.keys():
			self.fangjian = ch_fj_dict[self.chuanghao]
		else:
			self.fangjian = ""
		self.chuanghao = chuanghao
		#self.ruyuanriqi = ruyuanriqi # 2018-12-06
		if ruyuanriqi == "":
			self.ruyuanriqi = str(date.today())
		else:
			self.ruyuanriqi = ruyuanriqi
		# 创建两个空列表，仅通过tianjia-XX或shanchu-xx修改
		self.zhenduan = []
		self.tixingliebiao = []
		logging.info("创建了一个病人，姓名：%s" % self.xingming)
	def gaixingming(self, xingming):
		yuanming = self.xingming
		self.xingming = xingming
		logging.info("%s的姓名修改为：%s" % (yuanming, self.xingming))
	def gaixingbie(self, xingbie):
		self.xingbie = xingbie
		logging.info("%s的性别修改为：%s" % (self.xingming, self.xingbie))
	def gainianling(self, nianling):
		self.nianling = nianling
		logging.info("%s的年龄修改为：%s" % (self.xingming, self.nianling))
	def gaichuanghao(self, chuanghao):
		self.chuanghao = chuanghao
		if self.chuanghao in ch_fj_dict.keys():
			self.fangjian = ch_fj_dict[self.chuanghao]
		logging.info("%s的房间-床号信息修改为：%s-%s" % (self.xingming, self.fangjian, self.chuanghao))
	def gairuyuanriqi(self, ruyuanriqi):
		self.ruyuanriqi = ruyuanriqi
		logging.info("%s的入院日期修改为：%s" % (self.xingming, self.ruyuanriqi))
	def tianjiazhenduan(self, zhenduan):
		if type(zhenduan) == type(""):
			zhenduan = [zhenduan]
		for zd in zhenduan:
			if zd not in self.zhenduan:
				self.zhenduan.append(zd)
		logging.info("%s添加了新的诊断，当前为：%s" % (self.xingming, self.zhenduan))
	def shanchuzhenduan(self, zhenduan):
		if type(zhenduan) == type(""):
			zhenduan = [zhenduan]
		for zd in zhenduan:
			if zd in self.zhenduan:
				self.zhenduan.remove(zd)
		logging.info("%s删除了诊断%s，当前为：%s" % (self.xingming, zhenduan, self.zhenduan))
	def tianjiatixing(self, riqi, shixiang):
		self.tixingliebiao.append([riqi, shixiang])
		self.tixingliebiao.sort()
		logging.info("添加了提醒后的列表为\n\t%s" % (self.tixingliebiao))
	def shanchutixing(self, riqi, shixiang):
		task = [riqi, shixiang]
		if task in self.tixingliebiao:
			self.tixingliebiao.remove(task)
		logging.info("删除提醒后的列表为\n\t%s" % (self.tixingliebiao))
	def qingkongtixing(self):
		self.tixingliebiao = []

class ChaFangQingDan:
	def __init__(self):
		logging.info("初始化查房清单")
		self.huanzheliebiao = []
		self.duqu()
	def baocun(self):
		# 先排列不包括加床的患者列表，再把加床附在后面
		hzchlb = {hz.chuanghao: hz for hz in self.huanzheliebiao}
		xinliebiao = []
		hzlb_keys = hzchlb.keys()
		########## 以下存在优化空间 ##########
		# 当前思路是：一般情况下没有重复床号的情况，也不太可能加床，所有用字典直接索引就行了
		# 但是一旦出现重复床号或者两个以上加床，就需要反复遍历患者列表以按照global变量定义好的顺序重新排列
		# 如果效率还可以就不优化了，反正一打开软件还得跳转到Pythonista再跳转到脚本，已经很低效了
		if len(hzchlb) == len(self.huanzheliebiao):
			logging.info("不存在相同床号，按照较快的方式重新排序")
			#说明没有相同床号的患者，包括加床（只有一个加床或没有加床）
			for ch in chuanghao:
				if ch in hzlb_keys:
					xinliebiao.append(hzchlb[ch])
		else:
			logging.info("存在相同床号，需要反复遍历以排序")
			#存在覆盖床号的情况
			for ch in chuanghao:
				if ch in hzlb_keys:
					for hz in self.huanzheliebiao:
						if ch == hz.chuanghao:
							xinliebiao.append(hz)
		########## 以上存在优化空间 ##########
		self.huanzheliebiao = xinliebiao
		try:
			with open("huanzheliebiao.pkl", "wb") as f:
				pickle.dump(self.huanzheliebiao, f)
			logging.info("将患者列表保存至huanzheliebiao.pkl文件中")
		except:
			logging.info("未能将患者列表保存至huanzheliebiao.pkl文件中，新建空列表")
	def duqu(self):
		try:
			with open("huanzheliebiao.pkl", "rb") as f:
				self.huanzheliebiao = pickle.load(f)
			logging.info("从huanzheliebiao.pkl中加载患者列表")
		except:
			logging.info("未能从huanzheliebiao.pkl中加载患者列表")
	def qingkong(self):
		self.huanzheliebiao = []
		logging.info("已将患者列表及huanzheliebiao.pkl清空")
		self.baocun()
	def tianjiahuanzhe(self, hz):
		self.huanzheliebiao.append(hz)
		logging.info("查房清单添加了新患：%s" % hz.xingming)
		self.baocun()
	def shanchuhuanzhe(self, hz):
		if hz in self.huanzheliebiao:
			self.huanzheliebiao.remove(hz)
			logging.info("将%s从查房列表中移除" % hz.xingming)
			self.baocun()
		else:
			logging.info("未能将%s从查房列表中移除" % hz.xingming)
	def widgetcontent(self):
		pstr = ""
		for hz in self.huanzheliebiao:
			pstr += "%s-%s %s %s%s %s\n" % (hz.fangjian, hz.chuanghao, hz.xingming, hz.nianling, hz.xingbie, hz.zhenduan)
			# 如果有今日事，分行打印
			for shi in self.jinrishi(hz.tixingliebiao):
				pstr += "\t%s\n" % shi
		return pstr
	def dayin(self):
		# 开始打印查房清单
		logging.info("执行了查房清单的打印功能")
		pstr = "---------- 今日事 ----------\n"
		for hz in self.huanzheliebiao:
			pstr += "%s-%s %s %s岁%s患 %s\n" % (hz.fangjian, hz.chuanghao, hz.xingming, hz.nianling, hz.xingbie, hz.zhenduan)
			# 如果有今日事，分行打印
			for shi in self.jinrishi(hz.tixingliebiao):
				pstr += "\t%s\n" % shi
		pstr += "---------- 明日事 ----------\n"
		for hz in self.huanzheliebiao:
			pstr += "%s-%s %s %s岁%s患 %s\n" % (hz.fangjian, hz.chuanghao, hz.xingming, hz.nianling, hz.xingbie, hz.zhenduan)
			# 如果有明日事，分行打印
			for shi in self.mingrishi(hz.tixingliebiao):
				pstr += "\t%s\n" % shi
		pstr += "---------- 何其多 ----------\n"
		for hz in self.huanzheliebiao:
			pstr += "%s-%s %s %s岁%s患 %s\n" % (hz.fangjian, hz.chuanghao, hz.xingming, hz.nianling, hz.xingbie, hz.zhenduan)
			# 如果有后天待办事项，分行打印
			for shi in self.heqiduo(hz.tixingliebiao):
				pstr += "\t%s\n" % shi
		pstr += "---------------------------\n"
		return pstr
	def jinrishi(self, tixingliebiao):
		# tixingliebiao = [[riqi, shixiang]]
		# str(date.today())
		jinrishiliebiao = []
		jintianriqi_str = str(date.today())
		for riqi, shixiang in tixingliebiao:
			if riqi == jintianriqi_str:
				jinrishiliebiao.append(shixiang)
		return jinrishiliebiao
	# TODO: 完成 明日事 和 何其多
	def mingrishi(self, tixingliebiao):
		mingrishiliebiao = []
		mingtianriqi_str = str(date.today()+timedelta(hours=24))
		for riqi, shixiang in tixingliebiao:
			if riqi == mingtianriqi_str:
				mingrishiliebiao.append(shixiang)
		return mingrishiliebiao
	def heqiduo(self, tixingliebiao):
		# 何其多 就是 后天
		heqiduoliebiao = []
		houtianriqi_str = str(date.today()+timedelta(hours=48))
		for riqi, shixiang in tixingliebiao:
			if riqi == houtianriqi_str:
				heqiduoliebiao.append(shixiang)
		return heqiduoliebiao
		
	# def str2riqi(self, riqi_str):
	# 	# 一定要这种格式：2018-12-17
	# 	return date(int(riqi_str[:4]), int(riqi_str[5:7]), int(riqi_str[8:10]))



##################################################
# TO DO:
# 打印功能未完成
# UI
# pushover 提醒
##################################################
if __name__ == "__main__":
	logging.basicConfig(level=logging.DEBUG)
	# CRITICAL > ERROR > WARNING > INFO > DEBUG > NOTSET 
	qd = ChaFangQingDan()
	#qd.qingkong()
	#p = HuanZhe(xingming="章金莱", chuanghao="42", nianling="56", xingbie="男", ruyuanriqi="2018-12-10")
	#q = HuanZhe(xingming="陶阿狗", nianling="30", xingbie="女")
	#qd.tianjiahuanzhe(p)
	#qd.tianjiahuanzhe(q)
	#p.tianjiazhenduan(["脑出血", "高血压", "透析"])
	#q.tianjiazhenduan(["糖尿病", "强直性脊柱炎"])
	#p.tianjiatixing("2018-12-16", "开降压药")
	#p.tianjiatixing("2018-12-17", "再开降压药")
	#p.tianjiatixing("2018-12-17", "中心静脉置管换药")
	#p.tianjiatixing("2018-12-18", "出院")
	#qd.baocun()
	qd.huanzheliebiao[0].gairuyuanriqi("2018-12-14")
	qd.huanzheliebiao[1].gairuyuanriqi("2018-12-18")
	qd.huanzheliebiao[2].gairuyuanriqi("2018-12-19")
	qd.huanzheliebiao[3].gairuyuanriqi("2018-12-20")
	qd.huanzheliebiao[4].gairuyuanriqi("2018-12-19")
	qd.huanzheliebiao[5].gairuyuanriqi("2018-12-14")
	qd.huanzheliebiao[6].gairuyuanriqi("2018-12-13")
	qd.huanzheliebiao[7].gairuyuanriqi("2018-12-18")
	qd.huanzheliebiao[8].gairuyuanriqi("2018-12-14")
	qd.huanzheliebiao[9].gairuyuanriqi("2018-12-21")
	qd.baocun()
	print(qd.widgetcontent())
	
