import ui, logging
from commandlinetool import HuanZhe, ChaFangQingDan
from commandlinetool import chuanghao, fangjian, ch_fj_dict
from datetime import date, timedelta

########## class ##########
class Sticker(ui.View):
	def __init__(self):
		pass
	def touch_ended(self, touch):
		#x, y = touch.location
		patient = qingdan.huanzheliebiao[self.index]
		qingdan.editingwhich = self.index
		logging.info("选择了%s的卡片，进入编辑模式" % patient.xingming)
		patient_screen_view.subviews[0].title = patient.chuanghao
		patient_screen_view.subviews[1].text = patient.xingming
		patient_screen_view.subviews[2].text = patient.nianling
		patient_screen_view.subviews[3].text = patient.ruyuanriqi
		patient_screen_view.subviews[4].text = " ".join(patient.zhenduan)
		if patient.xingbie == "男":
			patient_screen_view.subviews[5].selected_index = 0
		elif patient.xingbie == "女":
			patient_screen_view.subviews[5].selected_index = 1
		else:
			patient_screen_view.subviews[5].selected_index = -1
		txlb = []
		for tx in patient.tixingliebiao:
			txlb.append(tx[0] + "\t" + tx[1])
		#qingdan.old_things = txlb
		patient_screen_view.subviews[6].data_source = ui.ListDataSource(txlb) 
		patient_screen_view.subviews[6].reload()
		patient_screen_view.present("sheet")
		
########## def ##########
def getSticker(huanzhe, index):
	view = ui.load_view("patient_sticker")
	if huanzhe.fangjian == "重症":
		view.subviews[0].background_color = "red"
	view.subviews[2].text = huanzhe.chuanghao
	today = date.today()
	ryrq = date(int(huanzhe.ruyuanriqi[0:4]), int(huanzhe.ruyuanriqi[5:7]), int(huanzhe.ruyuanriqi[8:10]))
	date_delta = today - ryrq
	view.subviews[3].text = "%dd" % date_delta.days
	view.subviews[4].text = huanzhe.xingming
	jianjie = ""
	for zd in huanzhe.zhenduan:
		jianjie += zd
	view.subviews[5].text = jianjie
	m, n = index%4, index//4
	view.x = (8*(m+1))+(70*m)
	view.y = (8*(n+1))+(90*n)
	view.index = index
	
	return view

def selectBed(sender):
	# 加载 select_bed_no.pyui 然后画床号按钮 然后再画房间标签
	logging.info("开始构建选择床位视图，床位与房间两个数组长度理应相等：%d == %d ?" % (len(chuanghao), len(fangjian)))
	fj_no_dict = {}
	fj_list = []
	for i in fangjian:
		if i in fj_no_dict:
			fj_no_dict[i] += 1
		else:
			fj_no_dict[i] = 1
			fj_list.append(i)
	last_room = ""
	line, index = -1, -1
	sbn_baseview = ui.load_view("select_bed_no_screen")
	scv = sbn_baseview.subviews[0]
	#for scvs in scv.subviews:
	#	scv.remove_subview(scvs)
	scv.always_bounce_certical = True
	scv.shows_vertical_scroll_indicator = False
	scv.content_size = (320, 70*len(fj_list)+13)
	# 获取已占用床位
	occupied_beds = []
	for hz in qingdan.huanzheliebiao:
		if not hz.chuanghao in occupied_beds:
			occupied_beds.append(hz.chuanghao)
	for ch in chuanghao:
		this_room = ch_fj_dict[ch]
		if not this_room == last_room:
			line += 1
			index = 0
		# 纠正每个单间占一行的问题，会占用过多空白
		if ch in ["23", "24", "25", "26"]:
			line = 1
		if ch == "23":
			index = 1
		elif ch == "24":
			index = 2
		elif ch == "25":
			index = 3
		elif ch == "26":
			index = 4
		# 纠正结束
		b = ui.Button()
		b.x, b.y = 3+(53*index), 38+(70*line)
		b.width, b.height = 50, 32
		b.title = ch
		if not ch in occupied_beds or ch == "加":
			b.background_color = "#0055CC"
		else:
			b.background_color = "lightgrey"
		b.tint_color = "white"
		b.action = selectBedFinished
		scv.add_subview(b)
		index += 1
		last_room = this_room
	lb_index = 0
	for fj in fj_list:
		lb = ui.Label()
		lb.x, lb.y = 3, 70*lb_index+3
		# 纠正单间独占一行的问题
		if fj in ["908", "909", "910"]:
			lb_index -= 1
		if fj == "908":
			lb.x, lb.y = 53*1+3, 70*1+3
		elif fj == "909":
			lb.x, lb.y = 53*2+3, 70*1+3
		elif fj == "910":
			lb.x, lb.y = 53*3+3, 70*1+3
		lb.width, lb.height = (fj_no_dict[fj]*50)+((fj_no_dict[fj]-1)*3), 32
		lb.text = fj
		lb.alignment = ui.ALIGN_CENTER
		lb.background_color = "lightgrey"
		lb.text_color = "white"
		scv.add_subview(lb)
		lb_index += 1
	sbn_baseview.present("sheet")

def selectBedFinished(sender):
	patient_screen_view.subviews[0].title = sender.title	
	sender.superview.superview.close()

def minusday(sender):
	d=patient_screen_view.subviews[3].text
	rq=date(int(d[0:4]), int(d[5:7]), int(d[8:10]))
	rq-=timedelta(hours=24)
	patient_screen_view.subviews[3].text=str(rq)
	
def plusday(sender):
	d=patient_screen_view.subviews[3].text
	rq=date(int(d[0:4]), int(d[5:7]), int(d[8:10]))
	rq+=timedelta(hours=24)
	patient_screen_view.subviews[3].text=str(rq)

def addTask(sender):
	#print("给%s加鸡腿" % qingdan.huanzheliebiao[qingdan.editingwhich].xingming)	
	qingdan.old_things = sender.superview.subviews[6].data_source.items
	ui.load_view("add_task_screen").present("sheet")
		
def addTaskFinished(sender):
	sss = sender.superview.subviews
	if sss[0].text == "":
		dayslater = 0
	else:
		dayslater = int(sss[0].text)
	todo = sss[2].text
	td = date.today()
	tdta = timedelta(hours=dayslater*24)
	tododate = str(td + tdta)
	if not todo == "":
		qingdan.old_things.append(tododate + "\t" + todo)
	sender.superview.close()
	patient_screen_view.subviews[6].reload()
	
def confirm(sender):
	if qingdan.editingwhich == "*":
		hz = HuanZhe()
	else:
		hz = qingdan.huanzheliebiao[qingdan.editingwhich]
	uis = sender.superview.subviews
	if not uis[0].title == "床":
		hz.gaichuanghao(uis[0].title)
	hz.gaixingming(uis[1].text)
	hz.gainianling(uis[2].text)
	hz.gairuyuanriqi(uis[3].text)
	zd = uis[4].text.split(" ")
	while "" in zd:
		zd.remove("")
	hz.zhenduan = []
	hz.tianjiazhenduan(zd)
	hz.gaixingbie(uis[5].segments[uis[5].selected_index])
	hz.qingkongtixing()
	for tx in uis[6].data_source.items:
		a, b = tx.split("\t")
		hz.tianjiatixing(a, b)
	if qingdan.editingwhich == "*":
		qingdan.tianjiahuanzhe(hz)
	else:
		qingdan.baocun()
	sender.superview.close()
	loadMainScreen()
	# uis[6] 是患者的提醒事项列表 tableview 显示
	# 设计如何添加新提醒
	# 完成：如果是修改患者信息或添加提醒，传入HuanZhe，按确定按钮后 修改 而非 添加

def leave(sender):
	#如果是新建就不处理？
	if qingdan.editingwhich == "*":
		logging.info("新录入的患者还没有存储，选择出院没有意义，直接退出")
	else:
		# 在此处理删除和保存工作
		qingdan.shanchuhuanzhe(qingdan.huanzheliebiao[qingdan.editingwhich])
	sender.superview.close()
	loadMainScreen()
	
def loadMainScreen():
	#v = ui.load_view()
	#v = main_screen
	scrollview = main_screen.subviews[0]
	for old_view in scrollview.subviews:
		scrollview.remove_subview(old_view)
	
	stlist = []
	for index, hz in enumerate(qingdan.huanzheliebiao):
		stlist.append(getSticker(hz, index))
	
	scrollview.always_bounce_certical = True
	scrollview.shows_vertical_scroll_indicator = False
	p = len(stlist)//4+1
	scrollview.content_size = (320, (8*(p+1))+(90*p))
	for st in stlist:
		scrollview.add_subview(st)
	global ms_onscreen
	if not ms_onscreen:
		main_screen.present("sheet")
		ms_onscreen = True

def addPatient(sender):
	qingdan.editingwhich = "*"
	qingdan.old_things = []
	patient_screen_view.subviews[0].title = "床"
	patient_screen_view.subviews[1].text = ""
	patient_screen_view.subviews[2].text = ""
	patient_screen_view.subviews[3].text = str(date.today())
	patient_screen_view.subviews[4].text = ""
	patient_screen_view.subviews[5].selected_index = 0
	patient_screen_view.subviews[6].data_source = ui.ListDataSource([]) 
	patient_screen_view.subviews[6].reload()
	patient_screen_view.present("sheet")
	
def whatToDo(sender):
	print("hey new tasks")
	
########## run ##########
if __name__ == "__main__":
	global qingdan, main_screen, patient_screen_view, ms_onscreen
	ms_onscreen = False
	qingdan = ChaFangQingDan()
	qingdan.editingwhich = None
	main_screen = ui.load_view()
	patient_screen_view = ui.load_view("patient_screen")
	loadMainScreen()
