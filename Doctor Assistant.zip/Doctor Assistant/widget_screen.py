import ui, appex
from commandlinetool import HuanZhe, ChaFangQingDan

qingdan = ChaFangQingDan()
qingdan.dayin()


v = ui.TextView()
v.text = qingdan.widgetcontent()
#v.text = qingdan.dayin()
v.selectable = False
v.height = max(14.0 * (1+v.text.count("\n")), 120)
appex.set_widget_view(v)
