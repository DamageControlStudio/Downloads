//
//  UIDesignApp.swift
//  Shared
//
//  Created by putto on 7/6/21.
//

import SwiftUI

@main
struct UIDesignApp: App {
    @StateObject var store = MailStore()
    @State private var selectedLabel: String?
    @State private var selectedMail: Mail?
    
    var body: some Scene {
        WindowGroup {
            NavigationView {
                Sidebar(
                    store: store,
                    selectedFolder: $selectedLabel,
                    selectedMail: $selectedMail
                )

                Text("Select label...")
                Text("Select mail...")
            }
        }
    }
}
