# coding: utf-8
import clipboard, appex
from UTOPIA import Downloader

if __name__ == "__main__":
	url = appex.get_url()
	if not url:
		url = clipboard.get()
	if url.startswith("http"):
		print("What's in your head: %s'" % url)
		print('------------ UTOPIA ------------')
		d = Downloader(url, download_dir="../")
		d.start()
		# print('--------------------------------')
		clipboard.set("别偷看，姿势多。")
