# coding: utf-8
import clipboard, appex
import youtube_dl

if __name__ == "__main__":
	url = appex.get_url()
	if not url:
		url = clipboard.get()
	if url.startswith('http'):
		print("What's in your head: %s'" % url)
		print('---------- YouTube-dl ----------')
		opts = {
			'format': 'worstaudio',
			'outtmpl': '../%(title)s.%(ext)s'
		}
		with youtube_dl.YoutubeDL(opts) as ydl:
			ydl.download([url])
		print('---------- YouTube-dl ----------')
		clipboard.set("别偷看，姿势多。")
