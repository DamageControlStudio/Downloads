from urllib.parse import urlencode
from urllib.request import urlopen
from p7s_utils import cal_dlkey, cal_time_based_str
import clipboard, appex

# CONFIG
server_ip = "http://45.77.152.73"

def toast(dl_url):
	user = "putto"
	toast_url = '%s/toast' % server_ip
	postdata = urlencode({
		"url": dl_url,
		"key": cal_time_based_str(user)
		})
	postdata = postdata.encode('UTF-8')
	res = urlopen(toast_url, postdata)
	print(res.read().decode("UTF-8"))

	dlkey = cal_dlkey(dl_url, user)
	print("\nstart: %s/yesir\n" % server_ip)
	print("status: %s/status/%s\n" % (server_ip, dlkey))

def clean():
	user = "putto"
	toast_url = "%s/greatescape" % server_ip
	postdata = urlencode({
		"key": cal_time_based_str(user)
	})
	postdata = postdata.encode("UTF-8")
	res = urlopen(toast_url, postdata)
	print(res.read().decode("UTF-8"))
	
if __name__ == "__main__":
	dl_url = appex.get_url()
	if not dl_url:
		dl_url = clipboard.get()
	if dl_url.startswith("http"):
		print("What's in your head: %s'" % dl_url)
		print("----- Pandora's 7th son -----\n")
		toast(dl_url)
		clipboard.set("别偷看，姿势多。")
		print("-----------------------------")
	elif dl_url.startswith("greatescape"):
		clean()
		clipboard.set("别偷看，姿势多。")
