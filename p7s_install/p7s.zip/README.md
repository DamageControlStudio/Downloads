# Pandora's 7th son  

# version 0.6
crontab 清理  

===== 安装步骤 =====  
首先需同步服务器时间  
下载 install.sh 和 p7s.zip
sudo /bin/bash install.sh  
crontab -e  
- @reboot /bin/bash /usr/share/nginx/html/p7s_startup.sh  

===== 潜在问题 =====  
url 存储进 sqlite 安全  
当一个用户总是将视频url重复提交，状态会重写为0，这样又得 extract_info。可以考虑限制提交频率。  
如果提交不成功，可能是服务器时间或本地时间不准，又或者名字不在 userlist 中  
失败次数超过 MAX_FAIL_TIMES 时再次添加这个 url 不会成功  

===== 流程 =====  
所有 dl_status.NEW 的 url 都会检查属性，将非 video url 转换，  
当状态被标记为 dl_status.READY 时，同时一定生成了 dlkey 并添加进数据库，  
视频标记为 dl_status.DONE 时不代表下载完成，某些视频是分两部分下载，再 merge，此时可能是第一阶段完成了。  
所以检查未完成的列表时可以检索 percentage != 100 AND failtimes < MAX_FAIL_TIME  
可是没有这样实现的原因是希望失败过的任务放在最后执行  

# version_0.5 已归档  
# version_0.4 已归档  
# version_0.3 已归档  