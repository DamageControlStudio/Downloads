# Pandora's 7th son  

# version 0.8.3



===== 安装步骤 =====  
1. 确保服务器时间准确  

2. 下载安装文件  
wget https://github.com/DamageControlStudio/Downloads/raw/master/p7s_install/p7s.zip  
unzip -q p7s.zip
sudo /bin/bash p7s_install.sh  

3. 设置 crontab  
crontab -e  
- @reboot /bin/bash /usr/share/nginx/html/p7s_startup.sh  
- 0 8 * * *  /usr/share/nginx/html/p7s_env/bin/python /usr/share/nginx/html/p7s_cronclean.py  

4. 手动清理最后一个文件，避免下次下载变成 install.sh.1  
rm p7s_install.sh  

5. 可选    
- 通过 certbot 安装证书，配置 /etc/nginx/sites-available/default  
- 通过 CloudFlare 配置 https  

===== 潜在问题 =====  
url 存储进 sqlite 安全：检查不允许的字符比如空格？  
当一个用户总是将视频 url 重复提交，状态会重写为 0，这样又得 extract_info。可以考虑限制提交频率。  
如果提交不成功，可能是服务器时间或本地时间不准，又或者名字不在 userlist 中  
失败次数超过 MAX_FAIL_TIMES 时再次添加这个 url 不会成功  
