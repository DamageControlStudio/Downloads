# -*- coding: utf-8 -*-

from p7s_utils import del_files, init_logger
import logging

logger = logging.getLogger(__name__)
init_logger(logger, __name__)

if __name__ == "__main__":
    logger.info("由 crontab 指使 p7s_cronclean.py 进行清理工作")
    msg = del_files()
    logger.info(msg)