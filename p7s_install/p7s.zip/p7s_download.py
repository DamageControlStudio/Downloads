#!/usr/bin/python
# -*- coding: utf-8 -*-

import threading, queue
import sqlite3
from p7s_init import db_filename, MAX_FAIL_TIMES, DL_THREAD_NUM, download_dir, log_dir, dl_status
import youtube_dl
import os
import time
from p7s_utils import cal_dlkey, cal_time_based_str
import logging


class Son:
    """Pandora's 7th [son]"""
    def __init__(self, url, user):
        self.url = url
        self.user = user
        self.dlkey = cal_dlkey(url, user)

class P7SDL:
    def __init__(self):
        self.dl_queue = queue.Queue()
        self.url2user_dict = {}
        self.dlkey2percentage_dict = {}
        self.url2title_dict = {}
        self._prepare_downloadlist()
        self._update_dl_queue()

    def _extract_info(self, dl_url):
        try:
            logger.info("正在获取 [%s] 的信息。" % dl_url)
            return youtube_dl.YoutubeDL({"quiet": False}).extract_info(dl_url, download=False)
        except:
            logger.warning("获取 [%s] 的信息失败了，返回空字典。" % dl_url)
            return {}

    def _prepare_downloadlist(self):
        conn = sqlite3.connect(db_filename)
        results = conn.execute("SELECT url, username FROM downloadlist WHERE status = %d" % dl_status.NEW)
        for result in results:
            self.url2user_dict[result[0]] = result[1]
        conn.close()
        logger.info("当前数据库中 status 标记为 0 的 url 包括：")
        logger.info(self.url2user_dict)
        url_status_one = [] # 直接就可以下载的 url
        url_del = [] # playlist multi-video url_transparent
        url_extracted = [] # extract from playlist etc.
        url_redirect = [] # tuple: old -> new 
        temp_url2user_dict = {}
        for url in self.url2user_dict.keys():
            info = self._extract_info(url)
            if "is_live" in info.keys() and info["is_live"] == True:
                logger.info("[%s] 可能正在直播，下载会非常耗时，即将移除，请稍后重新添加。" % url)
                url_del.append(url)
                continue
            if "ext" in info.keys(): # video url
                url_status_one.append(url)
                url_redirect.append((url, url)) # 也应当添加到 redirectlist 中，避免查找麻烦
                self.url2title_dict[url] = info["title"]
            elif "_type" in info.keys(): # list or other url
                if info["_type"] in ["playlist", "muti_video"]:
                    for entry in info["entries"]:
                        url_extracted.append(entry["webpage_url"])
                        temp_url2user_dict[entry["webpage_url"]] = self.url2user_dict[url] # 临时放在这里，否则会引起 RuntimeError: dictionary changed size during iteration
                        url_redirect.append((url, entry["webpage_url"]))
                        self.url2title_dict[entry["webpage_url"]] = entry["title"]
                    url_del.append(url)
                elif info["_type"] in ["url", "url_transparent"]:
                    logger.debug("这里可能出问题，未经过测试。")
                    url_extracted.append(info["url"])
                    url_redirect.append((url, info["url"]))
                    self.url2title_dict[info["url"]] = info["title"]
            else:
                # 前两种都不是，那么或者是错误 url，或者是某些原因无法 extract_info。还是先删除了吧。
                url_del.append(url)
        self.url2user_dict.update(temp_url2user_dict)
        self._update_new_del(update_list=url_status_one, new_list=url_extracted, del_list=url_del, rd_list=url_redirect)

    def _update_new_del(self, update_list, new_list, del_list, rd_list):
        logger.info("根据 _prepare_downloadlist 结果更新数据库。")
        conn = sqlite3.connect(db_filename)
        for url in update_list:
            user = self.url2user_dict[url]
            dlkey = cal_dlkey(url, user)
            try:
                conn.execute("UPDATE downloadlist SET status = %d, dlkey = '%s', title = '%s' WHERE url = '%s'" % (dl_status.READY, dlkey, self.url2title_dict[url], url))
                logger.info("UPDATE downloadlist SET status = %d, dlkey = '%s', title = '%s' WHERE url = '%s'" % (dl_status.READY, dlkey, self.url2title_dict[url], url))
            except Exception as e:
                logger.warning(e)
        conn.commit()
        for url in new_list:
            user = self.url2user_dict[url]
            dlkey = cal_dlkey(url, user)
            try:
                conn.execute("INSERT INTO downloadlist (url, status, username, dlkey, title) VALUES ('%s', %d, '%s', '%s', '%s')" % (url, dl_status.READY, user, dlkey, self.url2title_dict[url]))
                logger.info("INSERT INTO downloadlist (url, status, username, dlkey, title) VALUES ('%s', %d, '%s', '%s', '%s')" % (url, dl_status.READY, user, dlkey, self.url2title_dict[url]))
            except Exception as e:
                logger.warning(e)
        conn.commit()
        for url in del_list:
            try:
                conn.execute("DELETE FROM downloadlist WHERE url = '%s'" % url)
                logger.info("DELETE FROM downloadlist WHERE url = '%s'" % url)
            except Exception as e:
                logger.warning(e)
        conn.commit()
        for old_url, new_url in rd_list:
            user = self.url2user_dict[old_url]
            # assert self.url2user_dict[old_url] == self.url2user_dict[new_url]
            dlkey = cal_dlkey(new_url, user)
            fromkey = cal_dlkey(old_url, user) # 可能会多个重复
            try:
                conn.execute("UPDATE downloadlist SET fromkey = '%s' WHERE dlkey = '%s'" % (fromkey, dlkey))
                logger.info("UPDATE downloadlist SET fromkey = '%s' WHERE dlkey = '%s'" % (fromkey, dlkey))
            except Exception as e:
                logger.warning(e)
        conn.commit()
        conn.close()

    def _update_dl_queue(self):
        conn = sqlite3.connect(db_filename)
        # 新的最稳
        results = conn.execute("SELECT url, username FROM downloadlist WHERE status = %d" % dl_status.READY)
        for result in results:
            son = Son(result[0], result[1])
            self.dl_queue.put(son)
        # 差点完成的也还行，出现几率较低
        results = conn.execute("SELECT url, username FROM downloadlist WHERE status = %d AND percentage < %d" % (dl_status.DONE, 100))
        for result in results:
            son = Son(result[0], result[1])
            self.dl_queue.put(son)
        # 失败过的放最后
        results = conn.execute("SELECT url, username FROM downloadlist WHERE status = %d AND failtimes <= %d" % (dl_status.FAIL, MAX_FAIL_TIMES))
        for result in results:
            son = Son(result[0], result[1])
            self.dl_queue.put(son)
        conn.close()

    def progress_hooker(self, d):
        dlkey = os.path.basename(d["filename"])[:32]
        if d["status"] == "finished":
            conn = sqlite3.connect(db_filename)
            try:
                conn.execute("UPDATE downloadlist SET status = %d, percentage = 100 WHERE dlkey = '%s'" % (dl_status.DONE, dlkey))
                logger.info("UPDATE downloadlist SET status = %d, percentage = 100 WHERE dlkey = '%s'" % (dl_status.DONE, dlkey))
            except Exception as e:
                logger.warning(e)
            conn.commit()
            conn.close()
        elif d["status"] == "error":
            conn = sqlite3.connect(db_filename)
            try:
                conn.execute("UPDATE downloadlist SET status = %d, failtimes = failtimes + 1 WHERE dlkey = '%s'" % (dl_status.FAIL, dlkey))
                logger.info("UPDATE downloadlist SET status = %d, failtimes = failtimes + 1 WHERE dlkey = '%s'" % (dl_status.FAIL, dlkey))
            except Exception as e:
                logger.warning(e)
            conn.commit()
            conn.close()
        elif d["status"] == "downloading":
            percentage = 0
            total_bytes = 0
            if not dlkey in self.dlkey2percentage_dict.keys():
                self.dlkey2percentage_dict[dlkey] = percentage
            if "total_bytes" in d.keys():
                total_bytes = d["total_bytes"]
            elif "total_bytes_estimate" in d.keys():
                total_bytes = d["total_bytes_estimate"]
            if total_bytes != 0:
                percentage = int(100.0 * d["downloaded_bytes"] / total_bytes) 
                if self.dlkey2percentage_dict[dlkey] != percentage:
                    self.dlkey2percentage_dict[dlkey] = percentage
                    conn = sqlite3.connect(db_filename)
                    try:
                        conn.execute("UPDATE downloadlist SET percentage = %d WHERE dlkey = '%s'" % (percentage, dlkey))
                        logger.info("UPDATE downloadlist SET percentage = %d WHERE dlkey = '%s'" % (percentage, dlkey))
                    except Exception as e:
                        logger.warning(e)
                    conn.commit()
                    conn.close()

    def _download(self, q):
        while not q.empty():
            one_son = q.get()
            ydl_opts = {
                "outtmpl": os.path.join(download_dir, one_son.dlkey + ".%(ext)s"),
                "quiet": True,
                "progress_hooks": [self.progress_hooker], 
                "keepvideo": True,
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                }],
            }
            with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                try:
                    ydl.download([one_son.url])
                except Exception as e:
                    logger.warning(e)
            q.task_done()

    def finish_the_job(self):
        workers = []
        for _ in range(DL_THREAD_NUM): 
            workers.append(threading.Thread(target=self._download, args=(self.dl_queue,)))
        for w in workers:
            w.setDaemon(True)
            w.start()
        self.dl_queue.join()



logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
log_filename = os.path.join(log_dir, "%s-%s.log" % (time.strftime("%Y-%m-%d", time.localtime()), "download"))
handler = logging.FileHandler(log_filename)
handler.setLevel(logging.INFO)
handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
logger.addHandler(handler)

if __name__ == "__main__":
    p7sdl = P7SDL()
    p7sdl.finish_the_job()
