#!/usr/bin/python
# -*- coding: utf-8 -*-

import sqlite3
import os

# config
DATABASE_FILENAME = "p7s_sqlite.db"
USER_LIST = ["putto"] # should not more than 5 names, slow performance
MAX_FAIL_TIMES = 5
DL_THREAD_NUM = 3

p7s_dir = os.path.dirname(os.path.realpath(__file__))
db_filename = os.path.join(p7s_dir, DATABASE_FILENAME)
download_dir = p7s_dir + os.sep + "files"
log_dir = p7s_dir + os.sep + "logs"

class dl_status():
    NEW = 0
    READY = 1
    DONE = 2
    FAIL = 9

def print_general_message():
    print("##### 一些初始化信息 #####")
    print("数据库名为 [%s]。" % DATABASE_FILENAME)
    print("最大失败次数设置为 [%d] 次，下载线程数为 [%d]。" % (MAX_FAIL_TIMES, DL_THREAD_NUM))
    print("文件将下载至 [%s] 目录下。" % download_dir)
    print("日志存放在 [%s] 目录下。" % log_dir)

def create_db():
    conn = sqlite3.connect(db_filename)
    # create downloadlist and userlist
    print("创建表 downloadlist 和 userlist。")
    try:
        conn.execute("""CREATE TABLE downloadlist 
        (id INTEGER PRIMARY KEY AUTOINCREMENT, 
        url TEXT UNIQUE NOT NULL, 
        status INTEGER NOT NULL DEFAULT 0, 
        failtimes INTEGER DEFAULT 0,  
        percentage INTEGER DEFAULT 0, 
        username TEXT,
        dlkey TEXT,
        fromkey TEXT,
        title TEXT DEFAULT "")""")
    except Exception as e:
        print("创建 downloadlist 时出现错误: %s。" % e)
    try:
        conn.execute("CREATE TABLE userlist (username TEXT UNIQUE NOT NULL)")
    except Exception as e:
        print("创建 userlist 时出现错误: %s。" % e)
    conn.commit()


    for user in USER_LIST:
        try:
            conn.execute("INSERT INTO userlist (username) VALUES ('%s')" % user)
            print("向 userlist 添加用户 [%s]。" % user)
        except Exception as e:
            print("向 userlist 添加用户 [%s] 时出现错误: %s。" % (user, e))
    conn.commit()
    conn.close()


if __name__ == "__main__":
    print_general_message()
    create_db()





# TODO autorun
# TODO autoclean