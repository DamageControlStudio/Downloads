#!/usr/bin/python
# -*- coding: utf-8 -*-

from urllib.parse import urlencode
from urllib.request import urlopen
from p7s_utils import cal_dlkey, cal_time_based_str

# dl_url = "https://www.bilibili.com/video/av74806780"
# dl_url = "https://www.bilibili.com/video/av74825639"
# dl_url = "https://www.bilibili.com/video/av74021059"
dl_url = "https://www.bilibili.com/video/av75181841"


# server_ip = "http://127.0.0.1:5000"
server_ip = "http://raspberrypi.local"

user = "putto"





toast_url = '%s/toast' % server_ip
postdata = urlencode({
    "url": dl_url,
    "key": cal_time_based_str(user)
    })
postdata = postdata.encode('UTF-8')
res = urlopen(toast_url, postdata)
print(res.read().decode("UTF-8"))

dlkey = cal_dlkey(dl_url, user)
print("\nstart: %s/yesir\n" % server_ip)
print("status: %s/status/%s\n" % (server_ip, dlkey))
