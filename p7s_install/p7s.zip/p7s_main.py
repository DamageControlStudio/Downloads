#!/usr/bin/python
# -*- coding: utf-8 -*-

from flask import Flask, request, redirect, send_from_directory, make_response, render_template
import sqlite3
import urllib, json
import os, threading
from p7s_setup import db_filename, download_dir, dl_status, log_dir
from p7s_utils import cal_dlkey, cal_time_based_str
from p7s_download import P7SDL
import logging, time


def is_key_available(key):
    conn = sqlite3.connect(db_filename)
    result = conn.execute("SELECT username FROM userlist")
    for r in result:
        if key == cal_time_based_str(r[0]):
            conn.close()
            return True, r[0]
    conn.close()
    return False, None

def add_url_to_downloadlist(url, user):
    conn = sqlite3.connect(db_filename)
    try:
        conn.execute("INSERT INTO downloadlist (url, username) VALUES ('%s', '%s')" % (url, user))
        logger.info("INSERT INTO downloadlist (url, username) VALUES ('%s', '%s')" % (url, user))
        conn.commit()
    except Exception as e:
        logger.warning(e)
        try:
            conn.execute("UPDATE downloadlist SET status = %d WHERE url = '%s'" % (dl_status.READY, url))
            logger.info("UPDATE downloadlist SET status = %d WHERE url = '%s'" % (dl_status.READY, url))
            conn.commit()
        except Exception as e:
            logger.warning(e)
    conn.close()

def get_files_info(key):
    conn = sqlite3.connect(db_filename)
    results = conn.execute("SELECT failtimes, percentage, dlkey, title FROM downloadlist WHERE fromkey = '%s'" % key)
    files_info = {}
    dlkey_list = []
    percentage_list = []
    failtimes_list = []
    title_list = []
    for result in results:
        [failtimes, percentage, dlkey, title] = result
        dlkey_list.append(dlkey)
        percentage_list.append(percentage)
        failtimes_list.append(failtimes)
        title_list.append(title)
    conn.close()
    key2files_dict = search_files_by_key_list(dlkey_list)
    file_list = []
    for key in dlkey_list:
        file_list.append(key2files_dict[key])
    filesize_list = get_file_size(file_list)
    files_info["dlkey_list"] = dlkey_list
    files_info["percentage_list"] = percentage_list
    files_info["failtimes_list"] = failtimes_list
    files_info["title_list"] = title_list 
    files_info["file_list"] = file_list
    files_info["filesize_list"] = filesize_list
    files_info["n"] = len(dlkey_list)
    files_info["fromkey"] = key
    return files_info

def search_files_by_key_list(key_list):
    key_dict = {}
    for key in key_list:
        key_dict[key] = []
    for filename in os.listdir(download_dir):
        str32 = filename[:32]
        if str32 in key_list and filename.count(".") == 1:
            key_dict[str32].append(filename)
    return key_dict

def get_file_size(file_list):
    filesize_list = []
    for files in file_list:
        size_list = []
        for file in files:
            size = os.path.getsize(os.path.join(download_dir, file))
            # size_list.append(size)
            size_list.append(readable_size(size))
        filesize_list.append(size_list)
    return filesize_list

def readable_size(size):
    # return string
    i = 0
    K = 1024.0
    unit = ["B", "KB", "MB", "GB", "TB", "PB"]
    while size >= K:
        size = size / K
        i = i + 1
    return "%.1f %s" % (size, unit[i])

app = Flask(__name__)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
log_filename = os.path.join(log_dir, "%s-%s.log" % (time.strftime("%Y-%m-%d", time.localtime()), "main"))
handler = logging.FileHandler(log_filename)
handler.setLevel(logging.INFO)
handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
logger.addHandler(handler)

@app.route("/")
def welcome():
    return render_template("welcome.html")

@app.route("/bye")
def bye():
    return "No more drinking"

@app.route("/toast", methods=["GET", "POST"])
def toast():
    if request.method == "POST":
        got_url = request.form["url"]
        got_key = request.form["key"]
        available_flag, user = is_key_available(got_key)
        if available_flag:
            logger.info("用户 [%s] 向 downloadlist 表中添加了 [%s]。" % (user, got_url))
            add_url_to_downloadlist(got_url, user)
            start_download()
            return "Give it to me"
        else:
            logger.info("用户提交不能识别的 key 导致 url 不能添加进数据库。")
    return redirect("/bye")

@app.route("/yesir")
def start_download():
    p7sdl = P7SDL()
    thread_name = "yesir"
    is_alive = False
    for t in threading.enumerate():
        if thread_name == t.getName():
            is_alive = True
    if not is_alive:
        dirty_work = threading.Thread(target=p7sdl.finish_the_job, name=thread_name)
        dirty_work.start()
        logger.info("后台获取视频：知道了，开始干活。")
    else:
        logger.info("后台获取视频：正干着呢，别催了。")
    return "Pshaw"

@app.route("/status/<key>")
def are_you_ready(key):
    files_info = get_files_info(key) # a dict like below
    return render_template("status.html", **files_info)

@app.route("/download/<filename>")
def download(filename):
    logger.info("提供名为 [%s] 的文件下载。" % filename)
    return send_from_directory(download_dir, filename, as_attachment=True)

@app.errorhandler(404)
def page_not_found(e):
    return redirect("/bye")

@app.errorhandler(500)
def server_error(e):
    return redirect("/bye")


if __name__ == "__main__":
    app.run(debug=True)