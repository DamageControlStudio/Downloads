#!/bin/bash

cd /usr/share/nginx/html
source p7s_env/bin/activate
gunicorn --bind=0.0.0.0:4321 --daemon p7s_main:app