#!/usr/bin/python
# -*- coding: utf-8 -*-

import hashlib
import time

def cal_dlkey(url, user):
    x = url + user
    return hashlib.md5(x.encode(encoding='UTF-8')).hexdigest()

def cal_time_based_str(str):
    _,_,_,h,m,_,_,d,_ = time.gmtime()
    x = "%s%d%d%d" % (str,d,h,m)
    return hashlib.md5(x.encode(encoding='UTF-8')).hexdigest()