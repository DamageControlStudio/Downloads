# -*- coding: utf-8 -*-
import hashlib
import time
import sqlite3
import os, shutil
import logging
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from p7s_init import key, iv
from p7s_init import log_dir, download_dir
from urllib import request
from urllib import parse
import requests
import threading
import os
import hashlib
import time
import sys
from math import ceil

# 不看https警告
requests.packages.urllib3.disable_warnings()

def md5(text):
    return hashlib.md5(text.encode(encoding='UTF-8')).hexdigest()

def cal_dlkey(url, user):
    x = url + user
    return hashlib.md5(x.encode(encoding='UTF-8')).hexdigest()

def cal_time_based_str(text):
    _,_,_,h,m,_,_,d,_ = time.gmtime()
    x = "%s%d%d%d" % (text,d,h,m)
    return hashlib.md5(x.encode(encoding='UTF-8')).hexdigest()

def init_logger(logger, name):
    logger.setLevel(logging.INFO)
    log_filename = os.path.join(log_dir, "%s-%s.log" % (time.strftime("%Y-%m-%d", time.localtime()), name))
    handler = logging.FileHandler(log_filename)
    handler.setLevel(logging.INFO)
    handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    logger.addHandler(handler)

def del_files():
    from p7s_init import download_dir, db_filename, dl_status
    message = ""
    shutil.rmtree(download_dir)
    os.mkdir(download_dir)
    try:
        conn = sqlite3.connect(db_filename)
        conn.execute("UPDATE downloadlist SET status = %d, percentage = 0" % dl_status.DONE)
        message = "UPDATE downloadlist SET status = %d, percentage = 0" % dl_status.DONE
        conn.commit()
        conn.close()
    except Exception as e:
        message = e
    return message

def encrypt_file(fullpath, title, ext, buffersize=256):
    buffersize *= 1024 # kb
    backend = default_backend()
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
    # file
    encryptor = cipher.encryptor()
    padder = padding.PKCS7(128).padder()
    d, f = os.path.split(fullpath)
    enc_file = os.path.join(d, f"{md5(f)}.enc")
    with open(fullpath, 'rb') as f_in, open(enc_file, 'wb') as f_out:
        term = ceil(os.path.getsize(fullpath)/buffersize)
        for i in range(term):
            tmp = f_in.read(buffersize)
            if i != term -1: # 不是最后一块，不需要 padding
                f_out.write(encryptor.update(tmp))
            else:
                padder = padding.PKCS7(128).padder()
                tmp = padder.update(tmp) + padder.finalize()
                f_out.write(encryptor.update(tmp))
    # info
    encryptor = cipher.encryptor()
    padder = padding.PKCS7(128).padder()
    enc_info = os.path.join(d, f"{md5(f)}.info")
    tmp = bytes(f"{title}***{ext}", encoding="UTF-8")
    tmp = padder.update(tmp) + padder.finalize()
    with open(enc_info, 'wb') as f_out:
        f_out.write(encryptor.update(tmp))
    # clear
    with open(fullpath, 'wb') as f:
        f.write(b"")


class Droplets:
    """
        水滴：一边下载，一边解密
    """
    def __init__(self, url, download_dir="./", blocks_num=5, max_retry_times=5):
        assert len(os.path.basename(url)) == 36 and url.endswith(".enc")
        self.url = url
        self.info_url = f"{self.url[:-4]}.info"
        print(self.info_url)
        filename = self.url.split("/")[-1]
        filename = parse.unquote(filename)
        self.filename = filename
        self.download_dir = download_dir
        self.blocks_num = blocks_num
        self.max_retry_times = max_retry_times
        self.retry_times = 0
        # 建立下载目录
        if not os.path.exists(self.download_dir):
            os.mkdir(self.download_dir)
        elif os.path.isfile(self.download_dir):
            os.remove(self.download_dir)
            os.mkdir(self.download_dir)
        # 建立缓存目录
        self.cache_dir = "./cache/"
        if not os.path.exists(self.cache_dir):
            os.mkdir(self.cache_dir)
        elif os.path.isfile(self.cache_dir):
            os.remove(self.cache_dir)
            os.mkdir(self.cache_dir)
        self.file_size = self.get_size()
        # 用于测速的停止信号和计量变量
        self.done = False
        self.downloaded_size = []
        self.downloaded_time = []
        # 为了能多线程下载并解密，每块一个 decryptor。使用前需初始化，传入前 16 字节作为 iv
        self.decryptors = []
        # 显示基本信息
        readable_size = self.get_readable_size(self.file_size)
        sys.stdout.write(f"---------- Droplets Downloader ----------\n[url] {self.url}\n[path] {self.download_dir+self.filename}\n[size] {readable_size}\n")

    def get_size(self):
        with request.urlopen(self.url) as req:
            content_length = req.headers["Content-Length"]
            return int(content_length)

    def get_readable_size(self, size):
        units = ["B", "KB", "MB", "GB", "TB", "PB"]
        unit_index = 0
        K = 1024.0
        while size >= K:
            size = size / K
            unit_index += 1
        return "%.1f %s" % (size, units[unit_index])

    def get_ranges(self):
        ranges = []
        assert self.file_size >= 16 * self.blocks_num # 最低的要求，再小就没必要分快了
        onepiece = ceil(self.file_size/self.blocks_num)
        while True: # 循环直到成为 16 的倍数
            if onepiece % 16 == 0:
                break
            onepiece += 1
        offset = 0
        for _ in range(self.blocks_num):
            if offset > self.file_size - 1: # 可能因 onepiece 向上调整导致最后一个 block 没内容了
                break
            start = offset
            end = start + onepiece - 1
            if end > self.file_size - 1:
                end = self.file_size - 1
            ranges.append((start, end))
            offset = end + 1
        self.blocks_num = len(ranges) # 修正分块数
        return ranges

    def start(self):
        if self.retry_times <= self.max_retry_times:
            thread_arr = []
            n = 0
            ranges = self.get_ranges()
            for (start, end) in ranges:
                # 开始前需要初始化 decryptor
                backend = default_backend()
                if n != 0:
                    _, iv_index = ranges[n-1]
                    headers = {'Range': f'Bytes={iv_index-15}-{iv_index}', 'Accept-Encoding': '*'}
                    req = requests.get(self.url, stream=True, verify=False, headers=headers)
                    enc_block_as_iv = req.content
                    cipher = Cipher(algorithms.AES(key), modes.CBC(enc_block_as_iv), backend=backend)
                    decryptor = cipher.decryptor()
                    self.decryptors.append(decryptor)
                else: # n == 0
                    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
                    decryptor = cipher.decryptor()
                    self.decryptors.append(decryptor)
                # 开始下载
                thread = threading.Thread(target=self.download, args=(start, end, n))
                thread_arr.append(thread)
                thread.start()
                n += 1
            speed_thread = threading.Thread(target=self.calculate_download_speed, args=())
            speed_thread.start()
            for t in thread_arr:
                t.join()
            self.inquire()
            self.sew_together()
        else:
            sys.stdout.write("I tried, now, tired\n")

    def download(self, start, end, event_num):
        cache_filename = self.cache_dir + self.filename + ".part_" + str(event_num) + "_" + str(self.blocks_num)
        total_size = end - start + 1
        if os.path.exists(cache_filename):
            now_size = os.path.getsize(cache_filename)
        else:
            now_size = 0
        if total_size - now_size > 0:
            headers = {'Range': 'Bytes=%d-%s' % (now_size+int(start), end), 'Accept-Encoding': '*'}
            sys.stdout.write("[part%d] from %d to %s\n" % (event_num, now_size+int(start), end))
            req = requests.get(self.url, stream=True, verify=False, headers=headers)
            with open(cache_filename, "ab") as cache:
                chunk_size = 4096
                for chunk in req.iter_content(chunk_size=chunk_size):
                    if chunk:
                        chunk = self.decryptors[event_num].update(chunk) # 解密
                        chunk_length = len(chunk) # chunk_length 是实际大小
                        # 最后一块的最后一些字节需要 unpadding
                        if event_num == self.blocks_num - 1 and total_size - now_size <= chunk_size:
                            unpadder = padding.PKCS7(128).unpadder()
                            chunk = unpadder.update(chunk) + unpadder.finalize()
                        now_size += chunk_length
                        cache.write(chunk)

    def calculate_download_speed(self):
        # 开始统计文件大小，计时，并计算速度
        lag_count = 10 # 计算过去 lag_count 次测量的平均速度
        file_list = [self.cache_dir + self.filename + ".part_" + str(i) + "_" + str(self.blocks_num) for i in range(self.blocks_num)]
        while not self.done:
            dwn_size = 0
            for f in file_list:
                try:
                    dwn_size += os.path.getsize(f)
                except:
                    pass
            self.downloaded_size.append(dwn_size)
            if len(self.downloaded_size) == lag_count:
                self.downloaded_size.pop(0)
            self.downloaded_time.append(time.time())
            if len(self.downloaded_time) == lag_count:
                self.downloaded_time.pop(0)
            s = self.downloaded_size[-1] - self.downloaded_size[0]
            t = self.downloaded_time[-1] - self.downloaded_time[0]
            if not t == 0:
                speed = s/1024/t
                percentage = self.downloaded_size[-1] / self.file_size * 100
                sys.stdout.write("\r[status] %.2f%% @ %.2fKB/s          " % (percentage, speed))
                sys.stdout.flush()
            time.sleep(1)
        # sys.stdout.write("\r[status] the Beatles: all together now\n")
        sys.stdout.flush()
    
    def inquire(self):
        backend = default_backend()
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
        decryptor = cipher.decryptor()
        unpadder = padding.PKCS7(128).unpadder()
        tmp = requests.get(self.info_url).content
        tmp = unpadder.update(decryptor.update(tmp)) + unpadder.finalize()
        tmp = tmp.decode()
        self.title, self.ext = tmp.split("***")

    def sew_together(self):
        # 进入缝合阶段说明下载完成，因为之前一步有 .join() 卡着
        complete_flag = True # 用于标记最后是否计算 SHA-256
        self.done = True
        full_filename = self.download_dir + f"{self.title}.{self.ext}"
        if os.path.exists(full_filename):
            os.remove(full_filename)
        ranges = self.get_ranges()
        with open(full_filename, "wb") as file:
            for i in range(self.blocks_num):
                cache_filename = self.cache_dir + self.filename + ".part_" + str(i) + "_" + str(self.blocks_num)
                start, end = ranges[i]
                tiger = end - start + 1 # 理想
                cat = os.path.getsize(cache_filename) # 现实
                # if cat != tiger: # 照猫画虎：画的不一样
                if cat < tiger - 16: # 解密后会被 unpadding 掉最多 16
                    sys.stdout.write("\r[status] oops... retry now\n")
                    complete_flag = False
                    self.retry_times += 1
                    self.start()
                    break
                with open(cache_filename, "rb") as part:
                    file.write(part.read())
        if complete_flag:
            # 由于可能发生内存不足，不再计算 sha256
            sys.stdout.write("\r[Bingo] Download complete.\n")

# if __name__ == "__main__":
#     d = Droplets("http://127.0.0.1:5000/download/4c9ab59219b9dac1cfe7db9bb3b89f5a.enc")
#     d.start()