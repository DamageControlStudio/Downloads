# -*- coding: utf-8 -*-

import hashlib
import time
import sqlite3
import os, shutil
import logging
from p7s_init import log_dir


def cal_dlkey(url, user):
    x = url + user
    return hashlib.md5(x.encode(encoding='UTF-8')).hexdigest()

def cal_time_based_str(str):
    _,_,_,h,m,_,_,d,_ = time.gmtime()
    x = "%s%d%d%d" % (str,d,h,m)
    return hashlib.md5(x.encode(encoding='UTF-8')).hexdigest()

def init_logger(logger, name):
    logger.setLevel(logging.INFO)
    log_filename = os.path.join(log_dir, "%s-%s.log" % (time.strftime("%Y-%m-%d", time.localtime()), name))
    handler = logging.FileHandler(log_filename)
    handler.setLevel(logging.INFO)
    handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    logger.addHandler(handler)

def del_files():
    from p7s_init import download_dir, db_filename, dl_status
    message = ""
    shutil.rmtree(download_dir)
    os.mkdir(download_dir)
    try:
        conn = sqlite3.connect(db_filename)
        conn.execute("UPDATE downloadlist SET status = %d, percentage = 0" % dl_status.DONE)
        message = "UPDATE downloadlist SET status = %d, percentage = 0" % dl_status.DONE
        conn.commit()
        conn.close()
    except Exception as e:
        message = e
    return message
